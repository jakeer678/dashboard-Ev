import React, { useState, useMemo } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';


const evData = [
  { make: "TESLA", model: "MODEL 3", count: 1250, year: 2022, range: 320, price: 45000, state: "CA", satisfaction: 95, emissions: 0 },
  { make: "NISSAN", model: "LEAF", count: 800, year: 2022, range: 220, price: 32000, state: "WA", satisfaction: 88, emissions: 0 },
  { make: "CHEVROLET", model: "BOLT", count: 600, year: 2022, range: 260, price: 38000, state: "CA", satisfaction: 85, emissions: 0 },
  { make: "FORD", model: "MACH-E", count: 750, year: 2022, range: 300, price: 48000, state: "TX", satisfaction: 90, emissions: 0 },
  { make: "TESLA", model: "MODEL Y", count: 1100, year: 2022, range: 330, price: 55000, state: "CA", satisfaction: 92, emissions: 0 },
  { make: "HYUNDAI", model: "IONIQ", count: 450, year: 2022, range: 280, price: 36000, state: "FL", satisfaction: 89, emissions: 0 }
];

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00C49F', '#FFBB28'];

export default function App() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [hoveredCard, setHoveredCard] = useState(null);
  
  const stats = useMemo(() => ({
    totalVehicles: evData.reduce((sum, item) => sum + item.count, 0),
    avgRange: Math.round(evData.reduce((sum, item) => sum + item.range, 0) / evData.length),
    avgPrice: Math.round(evData.reduce((sum, item) => sum + item.price, 0) / evData.length),
    topModel: evData.reduce((prev, current) => (prev.count > current.count) ? prev : current).model
  }), []);

  const marketShareData = evData.map((item, index) => ({
    name: item.make,
    value: Math.round((item.count / stats.totalVehicles) * 100)
  }));

  return (
    <div className="conatiner">
      <div >
        {/* Header */}
        <div >
          
          <p>
       Electric Vehicle Market Analysis
          </p>
        </div>

        {/* Filters */}
        <div>
          {['all', 'range', 'price', 'satisfaction'].map(filter => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`p-3 rounded-lg transition-all duration-300 ${
                activeFilter === filter
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'bg-white text-indigo-600 hover:bg-indigo-50'
              }`}
            >
              {filter.charAt(0).toUpperCase() + filter.slice(1)}
            </button>
          ))}
        </div>

        {/* Stats Cards */}
        <div className='containeSub'>
          {[
            { title: 'Total Vehicles', value: stats.totalVehicles.toLocaleString(), icon: '🚗' },
            { title: 'Average Range', value: `${stats.avgRange} mi`, icon: '⚡' },
            { title: 'Average Price', value: `$${stats.avgPrice.toLocaleString()}`, icon: '💰' },
            { title: 'Top Model', value: stats.topModel, icon: '🏆' }
          ].map((stat, index) => (
            <div
              key={index}
              className={`bg-white rounded-xl p-6 shadow-lg transform transition-all duration-300 ${
                hoveredCard === index ? 'scale-105' : ''
              }`}
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-gray-500 text-sm">{stat.title}</p>
                  <p className="text-2xl font-bold text-indigo-900">{stat.value}</p>
                </div>
                <span className="text-3xl">{stat.icon}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Market Share Pie Chart */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold mb-4 text-indigo-900">Market Share</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={marketShareData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {marketShareData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Range vs Price Scatter Plot */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold mb-4 text-indigo-900">Range vs Price</h3>
            <ResponsiveContainer width="100%" height={300}>
              <ScatterChart>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" dataKey="price" name="Price" unit="K" />
                <YAxis type="number" dataKey="range" name="Range" unit=" mi" />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter name="Models" data={evData} fill="#8884d8">
                  {evData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Scatter>
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          {/* Sales Trend Area Chart */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold mb-4 text-indigo-900">Sales Trend</h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={evData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="make" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="count" stroke="#8884d8" fill="#8884d8" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Satisfaction Ratings */}
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold mb-4 text-indigo-900">Satisfaction Ratings</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={evData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="model" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="satisfaction" fill="#82ca9d">
                  {evData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Additional Analysis Section */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <h3 className="text-lg font-semibold mb-4 text-indigo-900">Performance Metrics</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={evData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="model" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="range" stroke="#8884d8" />
              <Line type="monotone" dataKey="satisfaction" stroke="#82ca9d" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}